import React from "react";
import "./FormCardDes.css";

const FormCardDes = () => {
  return (
    <div className="formDescription">
      <p>Farming ends in 4 months</p>
    </div>
  );
};

export default FormCardDes;
